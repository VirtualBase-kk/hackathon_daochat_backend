exports.dbname = {
    Organization:process.env.SERVICE_NAME+"-Organization",
    Room:process.env.SERVICE_NAME+"-Room",
    Chat:process.env.SERVICE_NAME+"-Chat",
    User:process.env.SERVICE_NAME+"-User",
    Member:process.env.SERVICE_NAME+"-Member",
    Vote:process.env.SERVICE_NAME+"-Vote",
    VoteResult:process.env.SERVICE_NAME+"-VoteResult",
    SignMessage:process.env.SERVICE_NAME+"-SignMessage",
    TodoItem:process.env.SERVICE_NAME+"-TodoItem",
    WebsoketConnection: process.env.SERVICE_NAME+"-WebsoketConnection"
}
